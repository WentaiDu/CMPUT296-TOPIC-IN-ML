import numpy as np
import math
import random
import MLCourse.utilities as utils

# -------------
# - Baselines -
# -------------


class Regressor:
    """
    Generic regression interface; returns random regressor
    Random regressor randomly selects w from a Gaussian distribution
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.weights = None

    def getparams(self):
        return self.params

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.weights = np.random.rand(Xtrain.shape[1])

    def predict(self, Xtest):
        # Most regressors return a dot product for the prediction
        ytest = np.dot(Xtest, self.weights)
        return ytest
        
    def get_learned_params(self):
        return {}

class RangePredictor(Regressor):
    """
    Random predictor randomly selects value between max and min in training set.
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.min = 0
        self.max = 1

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.min = np.amin(ytrain)
        self.max = np.amax(ytrain)

    def predict(self, Xtest):
        ytest = np.random.rand(Xtest.shape[0])*(self.max-self.min) + self.min
        return ytest
        
    def get_learned_params(self):
        return {"Min":self.min, "Max": self.max}

class MeanPredictor(Regressor):
    """
    Returns the average target value observed; a reasonable baseline
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.mean = None

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.mean = np.mean(ytrain)

    def predict(self, Xtest):
        return np.ones((Xtest.shape[0],))*self.mean
        
    def get_learned_params(self):
        return {"Mean":self.mean}


# ---------
# - TODO: Question 3-a
# ---------

# Class for a simple stochastic gradient based regression
class SimpleRegression(Regressor):
    
    # Initializes parameters   
    def __init__(self, parameters = {}):
        self.params = utils.update_dictionary_items({'stepsize_b': 0.0001, 'epochs': 1}, parameters)
    
    # Learns weights for predictions 
    def learn(self, Xtrain, ytrain):        
        numsamples = Xtrain.shape[0]
        numfeatures = Xtrain.shape[1]
        
        # Initialize variables        
        self.b = np.random.rand(numfeatures)

        # Example of how to access params
        epochs = self.params['epochs']
        
        # Select if adaptive stepsize is needed, if not use a constant one
        stepsize = self.params['stepsize_b']
        epoch=0
        r_1=range(epochs)
        #print(str(epochs)+'11111')
        # Shuffle data for every epoch
        while epoch<epochs:
            random_sample= np.random.permutation(numsamples)
            sample=0
            r_2=range(numsamples)
            while sample <numsamples:
                grad = np.dot((np.dot(Xtrain[random_sample][sample, :],self.b)-ytrain[random_sample][sample]),Xtrain[random_sample][sample, :])
                step_size = (abs(grad)+1)**(-1)
                self.b=self.b -stepsize*grad
                sample+=1
            #loss_new=self.cost(Xtrain,self.b,ytrain)
            epoch+=1

    # Compute final converged weights to use for the predict(self, Xtest) method
    # Predicts output values with learned weights

    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.b)
        return ytest


    def cost(self,Xtrain,variables,ytrain):
        a=variables * Xtrain-ytrain
        return a
    def sigmoid(self, z):
    #Apply sigmoid activation function to scalar, vector, or matrix
        return 1/(1+np.exp(-z))
    
    # Returns learned parameters    
    def get_learned_params(self):
        return {"b":self.b}


# ---------
# - TODO: Question 3-c
# ---------

# Class for mini batch gradient based regression
class BatchSimpleRegression(Regressor):

    def __init__(self, parameters = {}):
        self.params = utils.update_dictionary_items({'stepsize_b': 0.0001, 'epochs': 1, 'batchsize': 25}, parameters)
        
    def learn(self, Xtrain, ytrain):                        
        numsamples = Xtrain.shape[0]
        numfeatures = Xtrain.shape[1]

        self.b = np.random.rand(numfeatures)
        epochs = self.params['epochs']  
        step_size = self.params['stepsize_b']
        span = self.params['batchsize']
        for a in range(epochs):
            random_sample = np.random.permutation(numsamples)
            Shuffle_X= Xtrain[random_sample]
            Shuffle_Y= ytrain[random_sample]

        for b in range(0, numsamples, span):
            c=b + span
            new_x=Shuffle_X[b:c]
            new_y=Shuffle_Y[b:c]
            grad = np.sum(np.dot((np.dot(new_x, self.b) - new_y), new_x))/span
            self.b -= grad/(1+abs(grad))
        
        
    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.b)
        return ytest
        
    def get_learned_params(self):
        return {"b":self.b}

# ---------
# - TODO: Question 3-f
# ---------

# Class for distribution regression
class DistributionRegression(Regressor):
       
    def __init__(self, parameters = {}):
        self.params = utils.update_dictionary_items({'stepsize_b': 0.0001, 'epochs': 1, 'stepsize_a': 0.0001}, parameters)
        
    def learn(self, Xtrain, ytrain):        
        numsamples = Xtrain.shape[0]
        numfeatures = Xtrain.shape[1]
        
        # Initialize variables
        self.b = np.random.rand(numfeatures)
        self.a = np.random.rand(numfeatures)
 
        # Example of how to access params
        epochs = self.params['epochs']
        
        # Select if adaptive stepsize is needed, if not use a constant one
        stepsize = self.params['stepsize_b']

        # Shuffle data for every epoch
        
        # Compute final converged weights to use for the predict(self, Xtest) method

    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.b)
        return ytest
                
    def get_learned_params(self):
        return {"b":self.b, "a": self.a}

