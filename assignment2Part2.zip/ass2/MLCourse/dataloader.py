from typing import Tuple, Union

import math
import numpy as np

####### Main load functions
def load_census(trainsize: int = 1000, testsize: int = 1000) -> Tuple[Tuple, Tuple]:
    """load_census.
    This function will take random samples from census income dataset and return these samples as two tuples containing training and test data respectively
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[Tuple, Tuple]
    """

    maxsamples = 32562
    strtype = 'a50'
    censusdtype={'names': ('age', 'workclass', 'fnlwgt', 'education', 'education-num', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'capital-gain', 'capital-loss', 'hours-per-week', 'native-country', 'income'), 'formats': ('f', strtype, 'f', strtype,'f',strtype,strtype,strtype,strtype,strtype,'f','f','f',strtype,strtype)}
    incomeindex = 14
    convs = {14: lambda s: int(b'=' in s)}
    
    dataset = np.loadtxt('datasets/censusincome.txt', delimiter=',',dtype=censusdtype,converters = convs)
    if not (trainsize+testsize) <= len(dataset):
        raise Exception("Error: trainsize + testsize which is {} is not lower than {} !".format(trainsize+testsize, len(dataset)))
    
    numsamples = dataset.shape[0]
    subsetsamples =  trainsize+testsize

    # Doing this specifically for census, since we do not want to add a bias unit
    # and because we cannot normalize features
    randindices = np.random.choice(numsamples,subsetsamples, replace=False)
    vals = np.zeros(subsetsamples)
    for ii in range(subsetsamples):
        if b'1' == dataset[randindices[ii]][incomeindex]:
            vals[ii] = 1.0

    Xtrain = dataset[randindices[0:trainsize]]
    ytrain = vals[0:trainsize]
    Xtest = dataset[randindices[trainsize:trainsize+testsize]]
    ytest = vals[trainsize:trainsize+testsize]

    # Remove the targets from Xtrain and Xtest
    allfeatures = list(censusdtype['names'][0:incomeindex])
    Xtrain = Xtrain[allfeatures]
    Xtest = Xtest[allfeatures]

    return ((Xtrain,ytrain), (Xtest,ytest))

def load_blog(trainsize: int = 5000, testsize: int = 5000) -> Tuple[Tuple, Tuple]:
    """load_blog.
    This function will take random samples from a blog dataset and return these samples as two lists containing training and test sets
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[list, list]
    """

    if trainsize + testsize < 5000:
        filename = 'datasets/blogData_train_small.csv'
    else:
        filename = 'datasets/blogData_train.csv'

    dataset = loadcsv(filename)
    if not (trainsize+testsize) <= len(dataset):
        raise Exception("Error: trainsize + testsize which is {} is not lower than {} !".format(trainsize+testsize, len(dataset)))

    trainset, testset = splitdataset(dataset, trainsize, testsize, featureoffset=50)

    return trainset,testset

def load_ctscan(trainsize: int = 5000, testsize: int = 5000) -> Tuple[list, list]:
    """load_ctscan.
    This function will take random samples from a CT scan dataset and return these samples as two lists containing training and test sets
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[list, list]
    """
    
    filename = 'datasets/slice_localization_data.csv'

    dataset = loadcsv(filename)
    if not (trainsize+testsize) <= len(dataset):
        raise Exception("Error: trainsize + testsize which is {} is not lower than {} !".format(trainsize+testsize, len(dataset)))
       
    trainset, testset = splitdataset(dataset, trainsize, testsize, featureoffset=1)

    return trainset, testset

def load_height_weight(trainsize: int = 4000, testsize: int = 4000) -> Tuple[list, list]:
    """load_height_weight.
    This function will take random samples from a dataset with height and weight values of different individuals and return these samples as two lists containing training and test sets
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[list, list]
    """

    filename = 'datasets/height_weight.csv'
    
    dataset = loadcsv(filename)
    if not (trainsize+testsize) <= len(dataset):
        raise Exception("Error: trainsize + testsize which is {} is not lower than {} !".format(trainsize+testsize,len(dataset)))
    
    dataset = dataset[:trainsize+testsize][:, 1:]
    trainset, testset = splitdataset(dataset, trainsize, testsize, featureoffset=0)
    return trainset, testset

    
def load_song(trainsize: int = 5000, testsize: int = 5000) -> Tuple[list, list]:
    """load_song.
    This function will take random samples from the million song dataset and return these samples as two lists containing training and test sets.
    
    Not a good dataset for feature selection or regression
    Standard linear regression performs only a little bit better than a random vector.
    Additional complex models, such as interesting kernels, are needed
    To improve performance
    
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[list, list]
    """
    
    if trainsize + testsize < 5000:
        filename = 'datasets/YearPredictionMSD_small.csv'
    else:
        filename = 'datasets/YearPredictionMSD.csv'
    
    dataset = loadcsv(filename)
    
    trainset, testset = splitdataset(dataset, trainsize, testsize, outputfirst=True)
    
    return trainset, testset

def load_susy(trainsize: int = 500, testsize: int = 1000) -> Tuple[list, list]:
    """load_susy.
    This function will take random samples from a subset of a physics classification dataset and return these samples as two lists containing training and test sets.
    
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[list, list]
    """
    
    filename = 'datasets/susysubset.csv'
    
    dataset = loadcsv(filename)
    
    trainset, testset = splitdataset(dataset,trainsize, testsize)
    
    return trainset, testset

def load_susy_complete(trainsize: int = 500, testsize: int = 1000) -> Tuple[list, list]:
    """load_susy_complete.
    This function will take random samples from a complete version of physics classification dataset and return these samples as two lists containing training and test sets.
    
    :param trainsize: number of randomly selected training examples
    :type trainsize: int
    :param testsize: number of randomly selected test examples
    :type testsize: int
    :rtype: Tuple[list, list]
    """

    filename = 'datasets/susycomplete.csv'
    
    dataset = loadcsv(filename)
    
    trainset, testset = splitdataset(dataset,trainsize, testsize,outputfirst=True)
    
    return trainset, testset

def load_madelon() -> Tuple[list, list]:
    """load_madelon.
    This function will load all of the samples of madelon dataset and return these samples as two lists containing training and test sets.
    
    :rtype: Tuple[list, list]
    """

    datasettrain = np.genfromtxt('datasets/madelon/madelon_train.data', delimiter=' ')
    trainlab = np.genfromtxt('datasets/madelon/madelon_train.labels', delimiter=' ')
    trainlab[trainlab==-1] = 0
    trainsetx = np.hstack((datasettrain, np.ones((datasettrain.shape[0],1))))
    trainset = (trainsetx, trainlab)

    datasettest = np.genfromtxt('datasets/madelon/madelon_valid.data', delimiter=' ')
    testlab = np.genfromtxt('datasets/madelon/madelon_valid.labels', delimiter=' ')
    testlab[testlab==-1] = 0
    testsetx = np.hstack((datasettest, np.ones((datasettest.shape[0],1))))
    testset = (testsetx, testlab)

    return trainset,testset

####### Helper functions

def loadcsv(filename: str) -> np.ndarray:
    """loadcsv.
    Loads a dataset
    :param filename: the name or address of the dataset file
    :type filename: str
    :rtype: np.ndarray
    """
    dataset = np.genfromtxt(filename, delimiter=',')
    return dataset

def splitdataset(dataset: Union[list, np.ndarray], trainsize: int, testsize: int,
        testdataset: Union[list, np.ndarray] = None, featureoffset: int = 0, outputfirst: bool = False):
    """splitdataset.
    Splits the dataset into a train and test split
    Assumes output variable is the last variable
 
    :param dataset: input dataset that we want to split to train & test sets
    :type dataset: Union[list, np.ndarray]
    :param trainsize: size of training set
    :type trainsize: int
    :param testsize: size of test set
    :type testsize: int
    :param testdataset: If there is a separate testset, it can be specified in testset
    :type testdataset: Union[list, np.ndarray]
    :param featureoffset: only features with equal or higher index of featureoffset will be considered
    :type featureoffset: int
    :param outputfirst: This indicates that y label of the dataset is the first feature
    :type outputfirst: bool
    """


   # Generate random indices without replacement, to make train and test sets disjoint
    randindices = np.random.choice(dataset.shape[0],trainsize+testsize, replace=False)
    featureend = dataset.shape[1]-1
    outputlocation = featureend
    
    if outputfirst:
        featureoffset = featureoffset + 1
        featureend = featureend + 1
        outputlocation = 0

    Xtrain = dataset[randindices[0:trainsize], featureoffset:featureend]
    ytrain = dataset[randindices[0:trainsize], outputlocation]
    Xtest = dataset[randindices[trainsize:trainsize+testsize], featureoffset:featureend]
    ytest = dataset[randindices[trainsize:trainsize+testsize], outputlocation]
    

    if testdataset is not None:
        Xtest = dataset[:, featureoffset:featureend]
        ytest = dataset[:, outputlocation]

    ## Normalize features, with maximum value in training set
    ## as realistically, this would be the only possibility
    # for ii in range(Xtrain.shape[1]):
    #    maxval = np.max(np.abs(Xtrain[:,ii]))
    #    if maxval > 0:
    #        Xtrain[:,ii] = np.divide(Xtrain[:,ii], maxval)
    #        Xtest[:,ii] = np.divide(Xtest[:,ii], maxval)

    # Removing the biases from the features and the output
    for ii in range(Xtrain.shape[1]):
       Xtrain[:, ii] = Xtrain[:, ii] - np.mean(Xtrain[:,ii])
       Xtest[:, ii] = Xtest[:, ii] - np.mean(Xtest[:,ii])
    ytrain[:] = ytrain[:] - np.mean(ytrain[:])
    ytest[:] = ytest[:] - np.mean(ytest[:])

    # Add a column of ones; done after to avoid modifying entire dataset
    #Xtrain = np.hstack((Xtrain, np.ones((Xtrain.shape[0],1))))
    #Xtest = np.hstack((Xtest, np.ones((Xtest.shape[0],1))))

    return ((Xtrain, ytrain), (Xtest, ytest))


def create_susy_dataset(filenamein: str, filenameout: str, maxsamples: int = 100000) -> None:
    """create_susy_dataset.
    This function will generate samples of susy dataset and will save them in a text file
    :param filenamein: address of input file
    :type filenamein: str
    :param filenameout: address of out file
    :type filenameout: str
    :param maxsamples: number of samples to generate
    :type maxsamples: int
    :rtype: None
    """
    
    dataset = np.genfromtxt(filenamein, delimiter=',')
    
    y = dataset[0:maxsamples,0]
    X = dataset[0:maxsamples,1:9]
    
    data = np.column_stack((X,y))

    np.savetxt(filenameout, data, delimiter=",")
