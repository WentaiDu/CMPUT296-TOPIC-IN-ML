import numpy as np
import MLCourse.utilities as utils


################################################################
############Q1: Regression###################
#########################################
class Regressor:
    """
    Generic regression interface; returns random regressor
    Random regressor randomly selects w from a Gaussian distribution
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.weights = None

    def getparams(self):
        return self.params

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.weights = np.random.rand(Xtrain.shape[1])

    def predict(self, Xtest):
        # Most regressors return a dot product for the prediction
        ytest = np.dot(Xtest, self.weights)
        return ytest

    def l2err(self, prediction, y):
        """ l2 error (i.e., root-mean-squared-error) RMSE http://statweb.stanford.edu/~susan/courses/s60/split/node60.html"""
        return np.linalg.norm(np.subtract(prediction, y)) / np.sqrt(y.shape[0])


class MeanPredictor(Regressor):
    """
    Returns the average target value observed; a reasonable baseline
    """
    def __init__(self, parameters = {}):
        self.params = parameters
        self.mean = None

    def learn(self, Xtrain, ytrain):
        # Learns using the traindata
        self.mean = np.mean(ytrain)

    def predict(self, Xtest):
        return np.ones((Xtest.shape[0],))*self.mean

    def get_learned_params(self):
        return {"Mean":self.mean}



# Graduate admissions dataset: ~1.0, Adagrad: ~0.8
class LinearRegression(Regressor):
    def __init__(self, parameters):

        self.params = parameters
        self.weights = None
        self.transfer = utils.sigmoid
        self.dtransfer = utils.dsigmoid
        self.stepsize_approach = self.params['stepsize_approach']
        self.epochs = self.params['num_epochs']
        self.batch_size = self.params['batch_size']

    def learn(self, X, y):
        a=X.shape[0]
        b=X.shape[1]
        self.weights=np.zeros(b)
        if self.stepsize_approach == 'heuristic':
            self.g=1
        else:
            self.h=np.zeros(b)
        new_a=int(a/self.batch_size)
        e=range(len(X))
        for e in range(0,self.epochs):
            for c in range(new_a):
                d= np.random.choice(range(len(X)),self.batch_size,replace=False)
                hps=np.dot(X[d,:],self.weights) - y[d]
                if self.stepsize_approach=='heuristic':
                    self.g+=np.linalg.norm(np.dot(hps.transpose(),X[d,:]),ord=1)/8
                    self.weights-=self.getStepSize(self.g)*np.dot(hps.transpose(),X[d,:])
                else:
                    self.h +=np.dot(hps.transpose(),X[d,:])**2
                    self.weights-=self.getStepSize(self.h)*np.dot(hps.transpose(),X[d,:])
    def getStepSize(self, gradinet):
        """
        returns step size based on the approach chosen
        """
        if self.stepsize_approach=='heuristic':
            value = 1/(1+gradinet)
        else:
            value= 1/np.sqrt(gradinet)
        return value

    def predict(self, Xtest):
        """
        Most regressors return a dot product for the prediction
        """
        ytest = np.dot(Xtest, self.weights)
        return ytest


# Graduate admissions dataset: ~1.0, AdaGrad: ~0.7
class PolynomialRegression(LinearRegression):
    """docstring for Po"""
    def __init__(self, parameters):

        self.params=parameters
        self.transfer=utils.sigmoid
        self.dtransfer=utils.dsigmoid
        self.weights1=None
        self.weights2=None
        self.stepsize_approach=self.params['stepsize_approach']
        self.epochs=self.params['num_epochs']
        self.batch_size = self.params['batch_size']

    def learn(self, X, y):
        a=X.shape[0]
        b=X.shape[1]
        self.weights=np.zeros(b)
        if self.stepsize_approach == 'heuristic':
            self.g1=1
            self.g2=1
        else:
            self.h1=np.zeros(b)
            self.h2=np.zeros(b)
        self.weights1=np.zeros(b)
        self.weights2=np.zeros(b)
        for e in range(8,self.epochs):
            for c in range(int(a//self.batch_size)):
                random=np.random.choice(range(len(X)),self.batch_size,replace=False)
                d=X[random,:]
                f=y[random]
                hps =np.dot(d,self.weights1)+np.dot(d**2,self.weights2)-f

                gradient1=np.dot(hps.transpose(),d)
                gradient2=np.dot(hps.transpose(),d**2)
                if self.stepsize_approach=='heuristic':
                    self.g1+=np.linalg.norm(gradient1,ord=1)/8
                    self.g2+=np.linalg.norm(gradient2,ord=1)/8
                    q=1/(1+self.g1)
                    w=1/(1+self.g2)
                else:
                    self.h1 +=gradient1**2
                    self.h2 +=gradient2**2
                    q=1/np.sqrt(self.h1)
                    w=1/np.sqrt(self.h2)
                self.weights1=self.weights1-q*gradient1
                self.weights2=self.weights2-w*gradient2
    def predict(self, Xtest):
        ytest = np.dot(Xtest, self.weights1)+ np.dot(Xtest**2, self.weights2)
        return ytest



################################################################
############Q3: Classification###################
#########################################

# Susy: ~50 error
class Classifier:
    def __init__(self, parameters = {}):
        """ Params can contain any useful parameters for the algorithm """
        self.params = {}

    def getparams(self):
        return self.params

    def learn(self, Xtrain, ytrain):
        """ Learns using the training data """
        pass

    def predict(self, Xtest, threshold=0.5):
        probs = np.random.rand(Xtest.shape[0])
        ytest = utils.threshold_probs(probs, threshold=threshold)
        return ytest


# Susy: ~24 error
class LogisticRegression(Classifier):
    def __init__(self, parameters):
        self.params = parameters
        self.weights = None
        self.transfer = utils.sigmoid
        self.dtransfer = utils.dsigmoid
        self.epochs = self.params['epochs']
        self.batch_size = self.params['batch_size']

    def learn(self, X, y):
        """
        implements SGD updates
        """
        a=X.shape[0]
        b=X.shape[1]

        self.weights=np.zeros(b)
        d=np.zeros(b)

        for e in range(0,self.epochs):
            for c in range(int(a//self.batch_size)):
                random = np.random.choice(range(len(X)),self.batch_size,replace=False)
                hps=self.dtransfer(np.dot(X[random,:],self.weights))-y[random]
                gradinet=sum(np.dot(hps.transpose(),X[random,:]))/self.batch_size
                d=gradinet**2 +d
                stepsize = 1 / np.sqrt(d)
                self.weights = self.weights - stepsize* gradinet


    def getStepSize(self,gradinet):
        stepsize=1/ np.sqrt(gradinet)
        return stepsize

    def predict(self, Xtest, threshold=0.5):
        p=utils.sigmoid(np.dot(-Xtest,self.weights))
        ytest=utils.threshold_probs(p,threshold=threshold)
        return ytest

# Susy: ~22 error
class PolynomialLogisticRegression(LogisticRegression):
    """docstring for Po"""
    def __init__(self, parameters):
        super(PolynomialLogisticRegression, self).__init__(parameters)
        self.weight1=None
        self.weight2=None
    def learn(self, X, y):
        """
        implements SGD updates
        """
        a=X.shape[0]
        b=X.shape[1]

        self.weights1=np.zeros(b)
        self.weights2=np.zeros(b)
        g1=np.zeros(b)
        g2=np.zeros(b)

        for e in range(0,self.epochs):
            for c in range(int(a//self.batch_size)):
                random = np.random.choice(range(len(X)),self.batch_size,replace=False)
                #hps=self.dtransfer(np.dot(X[random,:],self.weights1))-y[random]
                hps=self.dtransfer(np.dot(X[random,:],self.weights1))-y[random]
                gradinet1=sum(np.dot(hps.transpose(),X[random,:]))/self.batch_size
                gradinet2=sum(np.dot(hps.transpose(),X[random,:]**2))/self.batch_size
                g1=g1+gradinet1**2
                stepsize1 = 1 / np.sqrt(g1)
                g2=g2+gradinet2**2
                stepsize2 = 1 / np.sqrt(g2)
                self.weights1 = self.weights1 - stepsize1* gradinet1
                self.weights2 = self.weights2 - stepsize2* gradinet2


    def getStepSize(self,gradinet):
        stepsize=1/ np.sqrt(gradinet)
        return stepsize

    def predict(self, Xtest, threshold=0.5):
        p=utils.sigmoid(np.dot(-Xtest,self.weights1))+utils.sigmoid(np.dot(-Xtest,self.weights2))
        ytest=utils.threshold_probs(p,threshold=threshold)
        return ytest